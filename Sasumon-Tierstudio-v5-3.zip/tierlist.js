// Hier stehen nach dem JS-Export deine gespeicherten Tierlisten.
// null bedeutet: vorhandenen Browser-Stand verwenden.
window.SASUMON_TIERLIST = null;
